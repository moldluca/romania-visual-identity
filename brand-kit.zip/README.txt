ROMÂNIA — IDENTITATE VIZUALĂ NAȚIONALĂ
Brand Kit 2026

CONȚINUT:
  logo-png/         — Logo-uri PNG (8 variante)
  logo-svg/         — Logo-uri SVG (vectorial)
  logo-transparent/ — Logo-uri PNG cu fundal transparent (pentru web)
  brandbook/        — Brand Book complet (132 pagini, deschideți index.html)
  referat.html      — Referat de prezentare brand de țară

PALETĂ CULORI:
  Albastru profund   #0B3C5D
  Galben vibrant     #FFC72C
  Roșu accent        #C8102E
  Verde natură       #2E7D32

TIPOGRAFIE:
  Titluri: Montserrat | Text: Open Sans | Premium: Poppins

© 2026 România · Identitate Vizuală Națională
