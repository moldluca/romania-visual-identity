ROMÂNIA — IDENTITATE VIZUALĂ NAȚIONALĂ
Brand Kit 2026

CONȚINUT:
  logo-png/         — Logo-uri PNG (8 variante: fundal alb/negru, orizontal, simbol, text)
  logo-svg/         — Logo-uri SVG (versiuni vectoriale)
  logo-transparent/ — Logo-uri PNG cu fundal transparent (pentru web/dark themes)
  brand-book.html   — Brand Book complet (21 pagini A4, deschideți în browser)
  brand-book.pptx   — Brand Book în format PowerPoint

PALETĂ CULORI:
  Albastru profund   #0B3C5D
  Galben vibrant     #FFC72C
  Roșu accent        #C8102E
  Verde natură       #2E7D32
  Albastru deschis   #4DA8DA

TIPOGRAFIE:
  Titluri:  Montserrat (300-900)
  Text:     Open Sans (300-700)
  Premium:  Poppins (300-700)

© 2026 România · Identitate Vizuală Națională
